/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog5121_assignment01_kiarasingh_st10215222;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class PROG5121_Assignment01_KiaraSingh_ST10215222 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Kiara Singh
        ST10215222
        Assignment 01
        */
        
        Student student = new Student();
        
        //Welcome Message
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("***************************************");
        
        int menuSelection ;
        System.out.println("Enter (1) to launch manu or any other key to exit");
        
        Scanner kb = new Scanner(System.in);
        menuSelection = kb.nextInt();
        
        
        if (menuSelection == 1) 
        {
            while(true){
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");
            
            Scanner sc = new Scanner(System.in);
            menuSelection = sc.nextInt();
        
        
        
        switch (menuSelection)
        {
            case 1 : student.SaveStudent(System.in);
            break;
            case 2 : student.SearchStudent();
            break;
            case 3 : student.DeleteStudent() ;
            break;
            case 4 : student.StudentReport();
            break;
            case 5: student.ExitStudentApplication();
            break;
            default: System.out.println("Invalid choice!");
            
        }//end switch
        }//end while
        }//end if
        else
        {
           System.exit(0);
        }//end else
    }
    
}
