/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121_assignment01_kiarasingh_st10215222;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class Student {
    
    //ArrayLists
    public ArrayList <Integer> studentID = new ArrayList<>();
    public ArrayList <String> studentName = new ArrayList<>();
    public ArrayList <Integer> studentAge = new ArrayList<>();
    public ArrayList <String> studentEmail = new ArrayList<>();
    public ArrayList <String> studentCourse = new ArrayList<>();
    
    //Method Create a new student
    public void SaveStudent(InputStream inputStream)
    {
        Scanner sc = new Scanner(inputStream);
       
        System.out.println("Enter the student id: ");
        studentID.add(sc.nextInt());
        
        System.out.println("Enter the student name: ");
        studentName.add(sc.next());
        
        int age = 0;
        
        while (true)
        {
            System.out.println("Enter the student age: ");
            
            if (sc.hasNextInt())
            {
                age = sc.nextInt();
                
            if (age >= 16)
            {
                studentAge.add(age);
                break;
                
            }//end if 2
            else
            {
                System.out.println("Enter the student age: " + age + "\n" + 
                                   "You have entered a incorrect student age!!!");
            }//end else 1
                
            }//end if 1
            else 
            {
                System.out.println("Enter the student age: " + age + "\n" + 
                                   "You have entered a incorrect student age!!!");
            
                System.out.println("Please re-enter the student age >> ");
                sc.next();
                
            }//end else 2
            
        }//end while
        
        
        System.out.println("Enter the student email: ");
        studentEmail.add(sc.next());
        
        System.out.println("Enter the student course: ");
        studentCourse.add(sc.next());
        
        System.out.println("\nCAPTURE A NEW STUDENT");
        System.out.println("****************************");
        
        System.out.println("Enter the student id: " + studentID + "\n" +
                           "Enter the student name: " + studentName + "\n" +
                           "Enter the student age: " + studentAge + "\n" + 
                           "Enter the student email: " + studentEmail + "\n" + 
                           "Enter the student course: " + studentCourse + "\n" 
                          );
        
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        int choice = sc.nextInt();
        
        if (choice == 1) 
        {
            return;
        }
        else
        {
            System.out.println("Exiting the application");
            sc.close();
            System.exit(0);
        }
    } // end of SaveStudent
            
    
    public void SearchStudent()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the student ID to search: ");
        
        int inputID ;
        
        if (sc.hasNextInt()) 
        {
            inputID = sc.nextInt();
        
        for (int i = 0; i < studentID.size() -1; i++) 
        {
            if (studentID.get(i) == inputID) 
            {
                System.out.println("*************************");
                System.out.println("STUDENT ID: " + studentID.get(i));
                System.out.println("STUDENT NAME: " + studentName.get(i));
                System.out.println("STUDENT AGE: " + studentAge.get(i));
                System.out.println("STUDENT EMAIL: " + studentEmail.get(i));
                System.out.println("STUDENT COURSE: " + studentCourse.get(i));
                System.out.println("*************************");
                
            }//end if
            else
            {
                System.out.println("Student with Student ID: " + inputID + " was not found!");
                
            }//end else
            
        }//end for
        }
        else {
        System.out.println("Invalid input. Please enter a valid student ID.");
    }
        
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        int choice = sc.nextInt();
        
        if (choice == 1) 
        {
            return;
        }
        else
        {
            System.out.println("Exiting the application");
            sc.close();
            System.exit(0);
        }
        
    }// end of SearchStudent
    
    
    public void DeleteStudent()
    {
        int studentIndex = -1;
        int inputIDToDelete;
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the student id to delete: ");
        inputIDToDelete = sc.nextInt();
        
        for (int i = 0; i < studentID.size(); i++) 
        {
            if (studentID.get(i) == inputIDToDelete) 
            {
                studentIndex = i;
                break;
            }//end if
        }//end for
        
        if (studentIndex != -1) 
        {
            System.out.println("Are you sure you want to delete student " + inputIDToDelete + " from the system? Yes(y) to delete.");
            String confirmation = sc.next();
            
            if (confirmation.equalsIgnoreCase("Y")) 
            {
                studentID.remove(studentIndex);
                studentName.remove(studentIndex);
                studentAge.remove(studentIndex);
                studentEmail.remove(studentIndex);
                studentCourse.remove(studentIndex);
                
                System.out.println("*************************");
                System.out.println("Student with Student ID: " + inputIDToDelete + " WAS deleted!");
                System.out.println("*************************");
            }//end if 2
            else
            {
                System.out.println("Delete Canceled!");
            }
        }//end if 1
        else
        {
            System.out.println("Student with ID: " + inputIDToDelete + " was not found");
        }
        
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        int choice = sc.nextInt();
        
        if (choice == 1) 
        {
            return;
        }
        else
        {
            System.out.println("Exiting the application");
            sc.close();
            System.exit(0);
        }
    
    }//end of DeleteStudent
    
    public void StudentReport()
    {
        if (studentID.isEmpty()) 
        {
            System.out.println("No student records captured!");
            return;
        }//end if
        
        for (int i = 0; i < studentID.size(); i++) 
        {
            System.out.println("STUDENT " + i +1);
            System.out.println("*******************************");
            
            System.out.println("STUDENT ID: " + studentID.get(i));
            System.out.println("STUDENT NAME: " + studentName.get(i));
            System.out.println("STUDENT AGE: " + studentAge.get(i));
            System.out.println("STUDENT EMAIL: " + studentEmail.get(i));
            System.out.println("STUDENT COURSE: " + studentCourse.get(i));
            
            System.out.println("*******************************");
            
        }//end for
        
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        
        if (choice == 1) 
        {
            return;
        }
        else
        {
            System.out.println("Exiting the application");
            sc.close();
            System.exit(0);
        }
        
    }//end of StudentReport
    
    public void ExitStudentApplication()
    {
        System.exit(0);
    }//end of ExitStudentApplication
    
    
    
}
