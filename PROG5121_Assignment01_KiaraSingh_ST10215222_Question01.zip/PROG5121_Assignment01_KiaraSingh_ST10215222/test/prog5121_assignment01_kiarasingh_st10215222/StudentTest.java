/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog5121_assignment01_kiarasingh_st10215222;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class StudentTest {
    
    public StudentTest() {
    }

    @Test
    public void testSaveStudent() {
        // Create a test input stream with mock user input
        InputStream inputStream = new ByteArrayInputStream("1\nKia\n21\nKia@gmail.com\nIT\n1\n".getBytes());
        
        // Redirect System.in to the test input stream
        System.setIn(inputStream);

        // Create a new Student object
        Student student = new Student();

        // Call the SaveStudent method
        student.SaveStudent(inputStream);

        // Perform assertions to check if the data was saved correctly
        assertEquals(1, student.studentID.size());
        assertEquals(1, student.studentName.size());
        assertEquals(1, student.studentAge.size());
        assertEquals(1, student.studentEmail.size());
        assertEquals(1, student.studentCourse.size());

        // Reset System.in to its original state
        System.setIn(System.in);
    }
    
    @Test
    public void testSearchStudent() {
        // Create a new Student object
        Student student = new Student();

        // Add some test data to the ArrayLists
        student.studentID.add(1);
        student.studentName.add("Kia");
        student.studentAge.add(21);
        student.studentEmail.add("Kia@gmail.com");
        student.studentCourse.add("IT");
        
        
       // Create a mock input stream with mock user input
        InputStream inputStream;
        inputStream = new ByteArrayInputStream("1\nKia\n21\nKia@gmail.com\nIT\n1\n".getBytes());

        // Redirect System.in to the test input stream
        System.setIn(inputStream);

        // Capture the original System.out
        PrintStream originalOut = System.out;

        // Create a ByteArrayOutputStream to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the SearchStudent method
        student.SearchStudent();

        // Reset System.in and System.out to their original states
        System.setIn(System.in);
        System.setOut(originalOut);

        // Get the captured output
        String consoleOutput = outputStream.toString();

        // Perform assertions to check if the student was found
        assertTrue(consoleOutput.contains("STUDENT ID: 1"));
        assertTrue(consoleOutput.contains("STUDENT NAME: Kia"));
        assertTrue(consoleOutput.contains("STUDENT AGE: 21"));
        assertTrue(consoleOutput.contains("STUDENT EMAIL: Kia@gmail.com"));
        assertTrue(consoleOutput.contains("STUDENT COURSE: IT"));
    }
    
     @Test
    public void testSearchStudent_StudentNotFound() {
        // Create a new Student object
        Student student = new Student();

        // Add some test data to the ArrayLists
        student.studentID.add(1);
        student.studentName.add("Kia");
        student.studentAge.add(21);
        student.studentEmail.add("Kia@gmail.com");
        student.studentCourse.add("IT");

        // Create a mock input stream with a student ID that doesn't exist
        InputStream inputStream = new ByteArrayInputStream("2\n".getBytes());

        // Redirect System.in to the test input stream
        System.setIn(inputStream);

        // Capture the original System.out
        PrintStream originalOut = System.out;

        // Create a ByteArrayOutputStream to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the SearchStudent method
        student.SearchStudent();

        // Reset System.in and System.out to their original states
        System.setIn(System.in);
        System.setOut(originalOut);

        // Get the captured output
        String consoleOutput = outputStream.toString();

        // Perform assertions to check if the student not found message is present
        assertTrue(consoleOutput.contains("Student with Student ID: 2 was not found!"));
    }
    
   @Test
    public void testDeleteStudent() {
        // Create a new Student object
        Student student = new Student();

        // Add a test student record to the ArrayLists
        student.studentID.add(1);
        student.studentName.add("Kia");
        student.studentAge.add(21);
        student.studentEmail.add("Kia@gmail.com");
        student.studentCourse.add("IT");

        // Create a mock input stream to simulate user input for deletion
        // Provide the student ID to delete (e.g., "1")
        // and a confirmation (e.g., "Y")
        InputStream inputStream = new ByteArrayInputStream("1\nY\n".getBytes());

        // Redirect System.in to the test input stream
        System.setIn(inputStream);

        // Call the DeleteStudent method
        student.DeleteStudent();

        // Reset System.in to its original state (important!)
        System.setIn(System.in);

        // Assertions: Check if the student was deleted successfully
        assertEquals(0, student.studentID.size());
    }
    
     @Test
    public void testDeleteStudent_StudentNotFound() {
        // Create a new Student object
        Student student = new Student();

        // Add some test student records to the ArrayLists (if needed)

        // Create a mock input stream with a student ID that doesn't exist in the records
        // and a confirmation (e.g., "Y") to delete
        InputStream inputStream = new ByteArrayInputStream("99\nY\n".getBytes());

        // Redirect System.in to the test input stream
        System.setIn(inputStream);

        // Call the DeleteStudent method
        student.DeleteStudent();

        // Reset System.in to its original state (important!)
        System.setIn(System.in);

        // Assertions: Check if the student was not found and nothing was deleted
        // You can assert based on the state of the ArrayLists or specific messages in the output
        // For example, check if the output contains "Student with ID: 99 was not found"
        // and if the ArrayLists remain unchanged.
        assertTrue(student.studentID.isEmpty()); // Assuming the student records are initially empty
    }
    
    @Test
    public void testStudentAge_StudentAgeValid() {
        // Create a new Student object
        Student student = new Student();

        // Create a mock input stream with a valid student age (e.g., "18")
        InputStream inputStream = new ByteArrayInputStream("18\n".getBytes());

        try {
            // Reset the InputStream position to the beginning of the data
            inputStream.reset();
        } catch (IOException e) {
            // Handle the IOException (e.g., log or throw a RuntimeException)
            throw new RuntimeException(e);
        }

        // Redirect System.in to the test input stream
        System.setIn(inputStream);

        // Call the SaveStudent method
        student.SaveStudent(inputStream);

        // Reset System.in to its original state (important!)
        System.setIn(System.in);

        // Assertions: Check if the student's age was added to the ArrayList
        // Use assertEquals with explicit casting to int to avoid ambiguity
        assertEquals(1, (int) student.studentAge.size()); // Assuming only one student was added
        assertEquals(18, (int) student.studentAge.get(0)); // Assuming the student's age is 18
    }
    
 @Test
    public void testStudentAge_StudentAgeInvalid() {
        // Create a new Student object
        Student student = new Student();

        // Provide invalid age input using a custom InputStream
        String input = "1\nKia\n-5\nKia@gmail.com\nIT\n1\n";  // Change the input as needed
        InputStream inputStream = new ByteArrayInputStream(input.getBytes());

        // Call the SaveStudent method with the custom InputStream
        student.SaveStudent(inputStream);

        // Assertions: Check if the student data was not added (since age is invalid)
        assertEquals(0, student.studentID.size());
        assertEquals(0, student.studentName.size());
        assertEquals(0, student.studentAge.size());
        assertEquals(0, student.studentEmail.size());
        assertEquals(0, student.studentCourse.size());
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        // Create a new Student object
        Student student = new Student();

        // Create a mock input stream with invalid age (non-numeric character)
        String input = "1\nKia\n20A\nKia@gmail.com\nCourse\n1\n";  // Age contains non-numeric character
        InputStream inputStream = new ByteArrayInputStream(input.getBytes());

         // Redirect System.in to the test input stream
    System.setIn(inputStream);

    // Call the SaveStudent method
    student.SaveStudent(inputStream);

    // Reset System.in to its original state
    System.setIn(System.in);

    // Perform assertions to check if the student was not saved (age is not added to the list)
    assertEquals(0, student.studentID.size());
    assertEquals(0, student.studentAge.size());
}
    
}
